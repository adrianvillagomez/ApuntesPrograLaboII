﻿namespace Formulario
{
    partial class Cuartel
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEnviar1 = new System.Windows.Forms.Button();
            this.bombero1 = new System.Windows.Forms.PictureBox();
            this.bombero2 = new System.Windows.Forms.PictureBox();
            this.bombero3 = new System.Windows.Forms.PictureBox();
            this.bombero4 = new System.Windows.Forms.PictureBox();
            this.btnEnviar2 = new System.Windows.Forms.Button();
            this.btnEnviar3 = new System.Windows.Forms.Button();
            this.btnEnviar4 = new System.Windows.Forms.Button();
            this.btnReporte4 = new System.Windows.Forms.Button();
            this.btnReporte3 = new System.Windows.Forms.Button();
            this.btnReporte2 = new System.Windows.Forms.Button();
            this.btnReporte1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bombero1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bombero2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bombero3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bombero4)).BeginInit();
            this.SuspendLayout();
            // 
            // btnEnviar1
            // 
            this.btnEnviar1.Location = new System.Drawing.Point(205, 13);
            this.btnEnviar1.Name = "btnEnviar1";
            this.btnEnviar1.Size = new System.Drawing.Size(64, 64);
            this.btnEnviar1.TabIndex = 0;
            this.btnEnviar1.Text = "Enviar";
            this.btnEnviar1.UseVisualStyleBackColor = true;
            this.btnEnviar1.Click += new System.EventHandler(this.btnEnviar1_Click);
            // 
            // bombero1
            // 
            this.bombero1.Image = global::Formulario.Properties.Resources.fireman;
            this.bombero1.Location = new System.Drawing.Point(13, 13);
            this.bombero1.Name = "bombero1";
            this.bombero1.Size = new System.Drawing.Size(64, 64);
            this.bombero1.TabIndex = 1;
            this.bombero1.TabStop = false;
            // 
            // bombero2
            // 
            this.bombero2.Image = global::Formulario.Properties.Resources.fireman;
            this.bombero2.Location = new System.Drawing.Point(13, 85);
            this.bombero2.Name = "bombero2";
            this.bombero2.Size = new System.Drawing.Size(64, 64);
            this.bombero2.TabIndex = 3;
            this.bombero2.TabStop = false;
            // 
            // bombero3
            // 
            this.bombero3.Image = global::Formulario.Properties.Resources.fireman;
            this.bombero3.Location = new System.Drawing.Point(13, 155);
            this.bombero3.Name = "bombero3";
            this.bombero3.Size = new System.Drawing.Size(64, 64);
            this.bombero3.TabIndex = 4;
            this.bombero3.TabStop = false;
            // 
            // bombero4
            // 
            this.bombero4.Image = global::Formulario.Properties.Resources.fireman;
            this.bombero4.Location = new System.Drawing.Point(13, 225);
            this.bombero4.Name = "bombero4";
            this.bombero4.Size = new System.Drawing.Size(64, 64);
            this.bombero4.TabIndex = 5;
            this.bombero4.TabStop = false;
            // 
            // btnEnviar2
            // 
            this.btnEnviar2.Location = new System.Drawing.Point(205, 85);
            this.btnEnviar2.Name = "btnEnviar2";
            this.btnEnviar2.Size = new System.Drawing.Size(64, 64);
            this.btnEnviar2.TabIndex = 6;
            this.btnEnviar2.Text = "Enviar";
            this.btnEnviar2.UseVisualStyleBackColor = true;
            this.btnEnviar2.Click += new System.EventHandler(this.btnEnviar2_Click);
            // 
            // btnEnviar3
            // 
            this.btnEnviar3.Location = new System.Drawing.Point(205, 155);
            this.btnEnviar3.Name = "btnEnviar3";
            this.btnEnviar3.Size = new System.Drawing.Size(64, 64);
            this.btnEnviar3.TabIndex = 7;
            this.btnEnviar3.Text = "Enviar";
            this.btnEnviar3.UseVisualStyleBackColor = true;
            this.btnEnviar3.Click += new System.EventHandler(this.btnEnviar3_Click);
            // 
            // btnEnviar4
            // 
            this.btnEnviar4.Location = new System.Drawing.Point(205, 225);
            this.btnEnviar4.Name = "btnEnviar4";
            this.btnEnviar4.Size = new System.Drawing.Size(64, 64);
            this.btnEnviar4.TabIndex = 8;
            this.btnEnviar4.Text = "Enviar";
            this.btnEnviar4.UseVisualStyleBackColor = true;
            this.btnEnviar4.Click += new System.EventHandler(this.btnEnviar4_Click);
            // 
            // btnReporte4
            // 
            this.btnReporte4.Location = new System.Drawing.Point(275, 224);
            this.btnReporte4.Name = "btnReporte4";
            this.btnReporte4.Size = new System.Drawing.Size(64, 64);
            this.btnReporte4.TabIndex = 16;
            this.btnReporte4.Text = "Reporte";
            this.btnReporte4.UseVisualStyleBackColor = true;
            // 
            // btnReporte3
            // 
            this.btnReporte3.Location = new System.Drawing.Point(275, 154);
            this.btnReporte3.Name = "btnReporte3";
            this.btnReporte3.Size = new System.Drawing.Size(64, 64);
            this.btnReporte3.TabIndex = 15;
            this.btnReporte3.Text = "Reporte";
            this.btnReporte3.UseVisualStyleBackColor = true;
            // 
            // btnReporte2
            // 
            this.btnReporte2.Location = new System.Drawing.Point(275, 84);
            this.btnReporte2.Name = "btnReporte2";
            this.btnReporte2.Size = new System.Drawing.Size(64, 64);
            this.btnReporte2.TabIndex = 14;
            this.btnReporte2.Text = "Reporte";
            this.btnReporte2.UseVisualStyleBackColor = true;
            // 
            // btnReporte1
            // 
            this.btnReporte1.Location = new System.Drawing.Point(275, 12);
            this.btnReporte1.Name = "btnReporte1";
            this.btnReporte1.Size = new System.Drawing.Size(64, 64);
            this.btnReporte1.TabIndex = 13;
            this.btnReporte1.Text = "Reporte";
            this.btnReporte1.UseVisualStyleBackColor = true;
            // 
            // Cuartel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 303);
            this.Controls.Add(this.btnReporte4);
            this.Controls.Add(this.btnReporte3);
            this.Controls.Add(this.btnReporte2);
            this.Controls.Add(this.btnReporte1);
            this.Controls.Add(this.btnEnviar4);
            this.Controls.Add(this.btnEnviar3);
            this.Controls.Add(this.btnEnviar2);
            this.Controls.Add(this.bombero4);
            this.Controls.Add(this.bombero3);
            this.Controls.Add(this.bombero2);
            this.Controls.Add(this.bombero1);
            this.Controls.Add(this.btnEnviar1);
            this.MaximizeBox = false;
            this.Name = "Cuartel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Estación de bomberos";
            this.Load += new System.EventHandler(this.Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bombero1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bombero2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bombero3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bombero4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEnviar1;
        private System.Windows.Forms.PictureBox bombero1;
        private System.Windows.Forms.PictureBox bombero2;
        private System.Windows.Forms.PictureBox bombero3;
        private System.Windows.Forms.PictureBox bombero4;
        private System.Windows.Forms.Button btnEnviar2;
        private System.Windows.Forms.Button btnEnviar3;
        private System.Windows.Forms.Button btnEnviar4;
        private System.Windows.Forms.Button btnReporte4;
        private System.Windows.Forms.Button btnReporte3;
        private System.Windows.Forms.Button btnReporte2;
        private System.Windows.Forms.Button btnReporte1;
    }
}

